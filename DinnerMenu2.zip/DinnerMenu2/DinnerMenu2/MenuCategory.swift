//
//  MenuCategory.swift
//  DinnerMenu2
//
//  Created by Edgar Montero on 9/2/24.
//

import Foundation


enum MenuCategory : String {
    case food = "Food"
    case drink = "Drink"
    case dessert = "Dessert"
}




