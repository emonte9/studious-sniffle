//
//  ContentView.swift
//  DinnerMenu2
//
//  Created by Edgar Montero on 9/1/24.
//

import SwiftUI

struct MockData {
    static let foodItems: [MenuItem] = [
        MenuItem(title: "Food1", price: 9.99, menuCategory: .food, ordersCount: 5, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food2", price: 12.99, menuCategory: .food, ordersCount: 10, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food3", price: 8.99, menuCategory: .food, ordersCount: 7, ingredients: [.pasta, .spinach, .tomatoSauce, .broccoli]),
        MenuItem(title: "Food4", price: 12.99, menuCategory: .food, ordersCount: 10, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food5", price: 9.99, menuCategory: .food, ordersCount: 5, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food6", price: 10.33, menuCategory: .food, ordersCount: 7, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food7", price: 5.55, menuCategory: .food, ordersCount: 1, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food8", price: 5.14, menuCategory: .food, ordersCount: 4, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food9", price: 12.99, menuCategory: .food, ordersCount: 11, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food10", price: 10.99, menuCategory: .food, ordersCount: 4, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food11", price: 16.99, menuCategory: .food, ordersCount: 5, ingredients: [.pasta, .tomatoSauce]),
        MenuItem(title: "Food12", price: 18.99, menuCategory: .food, ordersCount: 9, ingredients: [.pasta, .tomatoSauce]),
        // Add more food items
    ]
    
    static let drinkItems: [MenuItem] = [
        MenuItem(title: "Drink1", price: 1.99, menuCategory: .drink, ordersCount: 20, ingredients: [.tomatoSauce]),
        MenuItem(title: "Drink2", price: 2.99, menuCategory: .drink, ordersCount: 15, ingredients: [.carrot, .tomatoSauce]),
        MenuItem(title: "Drink3", price: 5.99, menuCategory: .drink, ordersCount: 15, ingredients: [.carrot, .spinach]),
        MenuItem(title: "Drink4", price: 6.99, menuCategory: .drink, ordersCount: 10, ingredients: [.carrot, .tomatoSauce]),
        MenuItem(title: "Drink5", price: 11.99, menuCategory: .drink, ordersCount: 12, ingredients: [.carrot, .pasta, .broccoli]),
        MenuItem(title: "Drink6", price: 15.99, menuCategory: .drink, ordersCount: 10, ingredients: [.carrot]),
        MenuItem(title: "Drink7", price: 2.99, menuCategory: .drink, ordersCount: 5, ingredients: [.carrot, .broccoli]),
        MenuItem(title: "Drink8", price: 8.99, menuCategory: .drink, ordersCount: 20, ingredients: [.carrot, .tomatoSauce, .broccoli,.pasta]),
        // Add more drink items
    ]
    
    static let dessertItems: [MenuItem] = [
        MenuItem(title: "Dessert1", price: 4.99, menuCategory: .dessert, ordersCount: 8, ingredients: [.spinach]),
        MenuItem(title: "Dessert2", price: 6.99, menuCategory: .dessert, ordersCount: 7, ingredients: [.carrot, .pasta]),
        
        MenuItem(title: "Dessert3", price: 2.99, menuCategory: .dessert, ordersCount: 6, ingredients: [.carrot,.spinach]),
        MenuItem(title: "Dessert4", price: 5.99, menuCategory: .dessert, ordersCount: 8, ingredients: [.carrot, .broccoli]),
        // Add more dessert items
    ]
}

class MenuViewViewModel: ObservableObject {
    @Published var foodItems: [MenuItem] = MockData.foodItems
    @Published var drinkItems: [MenuItem] = MockData.drinkItems
    @Published var dessertItems: [MenuItem] = MockData.dessertItems
    
    @Published var isSettingsPageOpen: Bool = false
}


protocol MenuItemProtocol {
    var id: UUID { get } // Getter for unique identifier
    var title: String { get } // Getter for title
    var price: Double { get } // Getter for price
    var menuCategory: MenuCategory { get } // Getter for category
    var ordersCount: Int { get set } // Getter and setter for orders count
    var ingredients: [Ingredient] { get set } // Getter and setter for ingredients
    
    // Method to get the price as an integer (for display purposes)
    func getPriceAsInt() -> Int
}


class MenuItem: MenuItemProtocol,Identifiable {
    var id = UUID() // Unique identifier for each menu item
    var title: String
    var price: Double
    var menuCategory: MenuCategory
    var ordersCount: Int
    var ingredients: [Ingredient]
    
    init(title: String, price: Double, menuCategory: MenuCategory, ordersCount: Int, ingredients: [Ingredient]) {
        self.title = title
        self.price = price
        self.menuCategory = menuCategory
        self.ordersCount = ordersCount
        self.ingredients = ingredients
    }
    
    // Method to get the price as an integer
    func getPriceAsInt() -> Int {
        return Int(price)
    }
}





struct ContentView: View {
    //@StateObject var viewModel = MenuViewModel()
    @StateObject var viewModel = MenuViewViewModel()
    
    
    var body: some View {
            NavigationView {
                VStack {
                    MenuGridView(viewModel: viewModel)
                }
                .navigationBarTitle("Menu")
                .navigationBarItems(trailing:
                    Button(action: {
                        viewModel.isSettingsPageOpen.toggle()
                    }) {
                        Text("Settings")
                    }
                    .sheet(isPresented: $viewModel.isSettingsPageOpen) {
                        MenuItemsOptionView(viewModel: viewModel)
                    }
                )
            }
            .background(Color.gray) // Set background color to white (or any other color you prefer)
        }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
