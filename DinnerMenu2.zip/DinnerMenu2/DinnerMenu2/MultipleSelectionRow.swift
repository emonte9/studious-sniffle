//
//  MultipleSelectionRow.swift
//  DinnerMenu2
//
//  Created by Edgar Montero on 9/2/24.
//

import SwiftUI

struct MultipleSelectionRow: View {
    var title: String
    var isSelected: Bool
    var action: () -> Void
    
    var body: some View {
        HStack {
            Text(title)
            Spacer()
            if isSelected {
                Image(systemName: "checkmark")
                    .foregroundColor(.blue)
            }
        }
        .contentShape(Rectangle())
        .onTapGesture(perform: action)
    }
}


#Preview {
    MultipleSelectionRow(title: "cookie", isSelected: true, action: {
            // This closure will be executed when the row is tapped
            print("Row tapped!")
        })
}
