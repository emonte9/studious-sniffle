//
//  MenuItemDetailsView.swift
//  DinnerMenu2
//
//  Created by Edgar Montero on 9/1/24.
//

import SwiftUI

struct MenuItemDetailsView: View {
    let menuItem: MenuItem

    var body: some View {
        NavigationView {
            
            
            VStack(alignment: .center) {
                Image("Little Lemon logo")
                    .resizable()
                    .scaledToFit()
                    
                Text("Price:").bold()
                Text("$\(menuItem.price, specifier: "%.2f")")
                Text("Ordered:")
                Text("\(menuItem.ordersCount)")
                Text("Ingredients:").bold()
                Text(menuItem.ingredients.map{$0.rawValue }
                .joined(separator: "\n")) .multilineTextAlignment(.center)// align text
                
            }
            .scaledToFit()
            .padding()
            
            .frame(maxWidth: .infinity, alignment: .center)
        }.navigationBarTitle(menuItem.title)
    }
}


#Preview {
    
    //MenuItem(title: "Burger", price: 9.99, menuCategory: .food, ordersCount: 5, ingredients: [.pasta, .tomatoSauce])
    MenuItemDetailsView(menuItem: MenuItem(title: "Burger", price: 9.99, menuCategory: .food, ordersCount: 5, ingredients: [.pasta, .tomatoSauce]))
}
