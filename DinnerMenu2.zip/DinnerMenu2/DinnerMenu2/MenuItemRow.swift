//
//  MenuItemRow.swift
//  DinnerMenu2
//
//  Created by Edgar Montero on 9/1/24.
//

import SwiftUI

struct MenuItemRow: View {
    var menuItem: MenuItem
    
    
    var body: some View {
        VStack(alignment: .center) {
            Image("Little Lemon logo")
                .resizable()
                .scaledToFit()
            
            
            Text(menuItem.title)
                .font(.headline)
                .frame(alignment: .center) // Center the text horizontally
                

            
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(10)
        
        
    }
}

#Preview {
    MenuItemRow(menuItem: MenuItem(title: "Burger", price: 9.99, menuCategory: .food, ordersCount: 5, ingredients: [.pasta, .tomatoSauce]))
}
