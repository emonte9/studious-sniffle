//
//  MenuGridView.swift
//  DinnerMenu2
//
//  Created by Edgar Montero on 9/1/24.
//

import SwiftUI

struct MenuGridView: View {
    @ObservedObject var viewModel: MenuViewViewModel
            
        let columns = [
            GridItem(.flexible()),
            GridItem(.flexible()),
            GridItem(.flexible())
        ]
        
    
        
    var body: some View {
        
            
        ScrollView {//food
            VStack(alignment: .leading) {
                Text("Food").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .font(.headline)
                    .padding(.leading) // Align left and add some padding
                    .padding(.top)
                
                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach(viewModel.foodItems.filter{$0.menuCategory == .food}) { menuItem in
                        NavigationLink(destination: MenuItemDetailsView(menuItem: menuItem)) {
                            MenuItemRow(menuItem: menuItem)
                        }
                    }
                }
                .padding()
                
                
                
                Text("Drinks").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .font(.headline)
                    .padding(.leading) // Align left and add some padding
                    .padding(.top)
                
                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach(viewModel.drinkItems.filter{$0.menuCategory == .drink}) { menuItem in
                        NavigationLink(destination: MenuItemDetailsView(menuItem: menuItem)) {
                            MenuItemRow(menuItem: menuItem)
                        }
                    }
                }
                .padding()
                
                
                Text("Dessert").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .font(.headline)
                    .padding(.leading) // Align left and add some padding
                    .padding(.top)
                
                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach(viewModel.dessertItems.filter{$0.menuCategory == .dessert}) { menuItem in
                        NavigationLink(destination: MenuItemDetailsView(menuItem: menuItem)) {
                            MenuItemRow(menuItem: menuItem)
                        }
                    }
                }
                .padding()
                
            }
        }
    }
}


#Preview {
    MenuGridView(viewModel: MenuViewViewModel())
}
