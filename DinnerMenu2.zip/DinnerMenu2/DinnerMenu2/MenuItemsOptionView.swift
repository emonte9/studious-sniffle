//
//  MenuItemsOptionView.swift
//  DinnerMenu2
//
//  Created by Edgar Montero on 9/1/24.
//

import SwiftUI

enum Category: String, CaseIterable, Identifiable {
    case food = "Food"
    case drink = "Drink"
    case dessert = "Dessert"
    
    var id: String { self.rawValue }
}

enum SortOption: String, CaseIterable, Identifiable {
    case mostPopular = "Most Popular"
    case price = "Price $-$$$"
    case alphabetical = "A-Z"
    
    var id: String { self.rawValue }
}




import SwiftUI

struct MenuItemsOptionView: View {
    @ObservedObject var viewModel: MenuViewViewModel
    @Environment(\.presentationMode) var presentationMode
    
    @State private var selectedCategories: Set<Category> = []
    @State private var selectedSortOption: Set<SortOption> = []
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("SELECTED CATEGORIES")) {
                    ForEach(Category.allCases) { category in
                        MultipleSelectionRow(title: category.rawValue, isSelected: self.selectedCategories.contains(category)) {
                            if self.selectedCategories.contains(category) {
                                self.selectedCategories.remove(category)
                            } else {
                                self.selectedCategories.insert(category)
                            }
                        }
                    }
                }
                
                Section(header: Text("SORT BY")) {
                    ForEach(SortOption.allCases) { category in
                        MultipleSelectionRow(title: category.rawValue, isSelected: self.selectedSortOption.contains(category)) {
                            if self.selectedSortOption.contains(category) {
                                self.selectedSortOption.remove(category)
                            } else {
                                self.selectedSortOption.insert(category)
                            }
                        }
                    }
                }
            }
            .navigationBarTitle("Filter Options")
            .navigationBarItems(trailing: Button("Done") {
                self.presentationMode.wrappedValue.dismiss()
            })
        }
        .background(Color(red: 0.9, green: 0.9, blue: 0.9))
    }
    
    
    
    
    
}

#Preview {
    MenuItemsOptionView(viewModel: MenuViewViewModel())
}
