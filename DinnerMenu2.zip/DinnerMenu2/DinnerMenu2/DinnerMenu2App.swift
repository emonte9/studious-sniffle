//
//  DinnerMenu2App.swift
//  DinnerMenu2
//
//  Created by Edgar Montero on 9/1/24.
//

import SwiftUI

@main
struct DinnerMenu2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
