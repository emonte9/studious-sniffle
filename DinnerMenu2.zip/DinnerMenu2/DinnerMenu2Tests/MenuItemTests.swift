//
//  MenuItemTests.swift
//  DinnerMenu2Tests
//
//  Created by Edgar Montero on 9/4/24.
//

import XCTest
@testable import DinnerMenu2

final class MenuItemTests: XCTestCase {

    func test_MenuItemTests(){
        let menuItem: MenuItem = MenuItem(title: "Drink2", price: 2.99, menuCategory: .drink, ordersCount: 15, ingredients: [.carrot, .tomatoSauce])
        
        let testIngredient: [Ingredient] =  [.carrot, .tomatoSauce]
        let testTitle: String = "Drink2"
        
        XCTAssertEqual(testTitle, menuItem.title)
        XCTAssertEqual(testIngredient, menuItem.ingredients)
        
        
    }

}
